﻿using System;
using System.Collections.Generic;

namespace LABDB1.Models;

public partial class Worker
{
    public int Id { get; set; }

    public string Login { get; set; } = null!;

    public string Password { get; set; } = null!;

    public string? Name { get; set; }

    public string? Surname { get; set; }

    public string? Lastname { get; set; }

    public DateOnly? LastDate { get; set; }

    public string? Time { get; set; }

    public string? Services { get; set; }

    public string? Scheta { get; set; }

    public int Role { get; set; }
}

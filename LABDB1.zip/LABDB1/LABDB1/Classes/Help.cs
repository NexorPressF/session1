using Avalonia.Controls;
using LABDB1.Models;

namespace LABDB1.Classes;

public static class Help
{
    public static ContentControl CCV = new ContentControl();
    public static TestContext DB = new TestContext();
}
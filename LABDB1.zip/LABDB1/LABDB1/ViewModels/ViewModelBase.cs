﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace LABDB1.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}
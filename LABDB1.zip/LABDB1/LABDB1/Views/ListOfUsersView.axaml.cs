using System.Linq;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using LABDB1.Classes;
using LABDB1.Models;
using Microsoft.EntityFrameworkCore;
using MsBox.Avalonia;

namespace LABDB1.Views;

public partial class ListOfUsersView : UserControl
{
    public ListOfUsersView()
    {
        InitializeComponent();
        Help.DB.UserInfos.Load();
        MainDG.ItemsSource = Help.DB.UserInfos.ToList();
    }

    private void AddBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.CCV.Content = new AddUserView();
    }

    private void RemakeBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        var user = MainDG.SelectedItem as UserInfo;
        if (user == null)
        {
            MessageBoxManager.GetMessageBoxStandard("Ошибка код 1488","Пользователь не выбран").ShowAsync();
            return;
        }
        Help.CCV.Content = new AddUserView(user.Id);

    }

    private void DeleteBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        var user = MainDG.SelectedItem as UserInfo;
        if (user == null)
        {
            MessageBoxManager.GetMessageBoxStandard("Ошибка код 1488","Пользователь не выбран").ShowAsync();
            return;
        }

        if (user != null)
        {
            Help.DB.UserInfos.Remove(user);
            Help.DB.SaveChanges();
            Help.DB.UserInfos.Load();
        }
    }
}
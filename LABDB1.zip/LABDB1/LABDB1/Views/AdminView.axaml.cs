using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using LABDB1.Classes;

namespace LABDB1.Views;

public partial class AdminView : UserControl
{
    public AdminView()
    {
        InitializeComponent();
    }

    private void ListBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.CCV.Content = new ListOfUsersView();
    }
}
using Avalonia.Controls;
using Avalonia.Interactivity;
using LABDB1.Classes;

namespace LABDB1.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        Help.CCV = MainCC;
        MainCC.Content = new MainView();
    }

    private void ExitBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.CCV.Content = new MainView();
    }
}
using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace LABDB1.Views;

public partial class LaborantView : UserControl
{
    public LaborantView()
    {
        InitializeComponent();
    }
}
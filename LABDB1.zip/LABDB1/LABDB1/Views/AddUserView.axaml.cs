using System.Linq;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using LABDB1.Classes;
using LABDB1.Models;
using Microsoft.EntityFrameworkCore;

namespace LABDB1.Views;

public partial class AddUserView : UserControl
{
    public int _id;
    public AddUserView(int id = -1)
    {
        InitializeComponent();
        Help.DB.UserInfos.Load();
        _id = id;

        if (id == -1)
        {
            AddSp.DataContext = new UserInfo();
        }
        else
        {
            var user = Help.DB.UserInfos.FirstOrDefault(el => el.Id == _id);
            AddSp.DataContext = user;
        }
    }

    private void AddUserBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        if (_id == -1)
        {
            Help.DB.UserInfos.Add(AddSp.DataContext as UserInfo);
        }
        Help.DB.SaveChanges();
        Help.CCV.Content = new ListOfUsersView();
    }
}
using System.Linq;
using Avalonia.Controls;
using Avalonia.Interactivity;
using LABDB1.Classes;
using Microsoft.EntityFrameworkCore;
using MsBox.Avalonia;

namespace LABDB1.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
        Help.DB.UserInfos.Load();
    }

    private void AutBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        var user = Help.DB.Workers.FirstOrDefault(el => el.Login == LoginTB.Text && el.Password == PassTB.Text);
        if (user == null)
        {
            MessageBoxManager.GetMessageBoxStandard("Ошибка код 5242", "Неверный логин или пароль").ShowAsync();
            LoginTB.Text = "";
            PassTB.Text = "";
            return;
        }
        if (user != null)
        {
            if (user.Role == 1)
            {
                Help.CCV.Content = new AdminView();
            }

            if (user.Role == 2)
            {
                Help.CCV.Content = new LaborantView();
            }

            if (user.Role == 3)
            {
                Help.CCV.Content = new LabIslView();
            }

            if (user.Role == 4)
            {
                Help.CCV.Content = new BuhgalterView();
            }
        }

    }
}